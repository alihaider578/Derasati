package com.derasati.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends Activity {
    private WebView webView;
    private AdView adView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout adContainer = new FrameLayout(this);
        adContainer.setBackgroundColor(0xFFF5F8FF);
        FrameLayout.LayoutParams adParams = new FrameLayout.LayoutParams(-1, -2);
        adParams.gravity = Gravity.BOTTOM;
        root.addView(adContainer, adParams);

        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");

        // Google test banner. Replace with your own ad unit ID before publishing.
        MobileAds.initialize(this, status -> loadTestBanner(adContainer));
    }

    private void loadTestBanner(FrameLayout container) {
        adView = new AdView(this);
        adView.setAdUnitId("ca-app-pub-3940256099942544/9214589741");
        adView.setAdSize(AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, 360));
        container.removeAllViews();
        container.addView(adView, new FrameLayout.LayoutParams(-1, -2));
        adView.loadAd(new AdRequest.Builder().build());
    }

    @Override protected void onDestroy() {
        if (adView != null) adView.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
